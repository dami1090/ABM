#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "comercio.h"
#define TAM 3
#define PROVE 11

int main()
{
    eProducto producto[TAM];
    // se declara y se inicia, si es x funcion hay q hacer uno x uno
    eProveedor prove[]={{95,"tarsa",1},{148,"halcon",1},{100,"gerli",1},{17,"translap",1},{22,"classA",1},{33,"coepS.A",1},{45,"verde",1},{178,"rojo",1},{293,"lanus",1},{159,"finDelMundo",1}};
    inicializar(producto,TAM);
    //iniciarHardcore(prove);
    char seguir='s';
    int opcion=0;

    while(seguir=='s')
    {
        printf("1- Agregar producto\n");
        printf("2- Modificar producto\n");
        printf("3- Borrar producto\n");
        printf("4- Imprimir lista\n");
        printf("5- Ordenar y mostrar\n\n");
        printf("6- Salir\n");

        setbuf(stdin,NULL);
        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                alta(producto,TAM);
                break;
            case 2:
                modificar(producto,TAM);
                break;
            case 3:
                baja(producto,TAM);
                break;
            case 4:
                mostrar(producto,TAM);
                break;
            case 5:
                break;
            case 6:
                seguir = 'n';
                break;

            default:
                system("cls");
                printf("\n\tOpcion invalida\n\n");
                break;
        }
        system("pause");
        system("cls");
    }

    return 0;
}
