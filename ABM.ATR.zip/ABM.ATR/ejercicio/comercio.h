#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct {
    int codigo;
    char descrip[501];
    float importe;
    int cantidad;
    int estado;
    int idProveedor;

}eProducto;

typedef struct
{
    int idProveedor;
    char nombreEmpresa[51];
    int estado;
}eProveedor;

/*typedef struct
{
    int codigo;
    int id;
}ProductoProveedor;*/


 //void iniciarHardcore(eProveedor lista[]); no se puede inicializar un hardcore con funcion
int inicializar(eProducto lista[],int);
int obtenerEspacioLibre(eProducto lista[],int);
int buscarProducto(eProducto lista[],int,int);
void alta(eProducto[],int);
void mostrar(eProducto[],int);
void mostrarProducto(eProducto);
int baja(eProducto[],int);
int modificar(eProducto[],int);
int buscarProveedor(eProveedor,int);

#endif // FUNCIONES_H_INCLUDED
